#pragma once
enum class KEY
{
	UP = 0, DOWN, SPACEBAR
};

void GameTitle();
int KeyController();
void GameInfo();
int DrawMenu();