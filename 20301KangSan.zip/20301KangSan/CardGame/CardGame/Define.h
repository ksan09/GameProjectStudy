#pragma once
#include <Windows.h>

enum class CARD_TYPE
{
	EMPTY = 0,
	ATK,
	DEF,
	EnemyATK,
	EnemyDEF,
};